## Problem statement :
To check whether a given schedule is recoverable or cascadeless.

## Usage :
- g++ -std=c++11 Recoverability.cpp
- ./a.out < input2.txt
