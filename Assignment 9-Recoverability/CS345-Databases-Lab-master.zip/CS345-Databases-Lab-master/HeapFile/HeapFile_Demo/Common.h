#define DISK_FILE_SIZE 1000
#define DISK_PAGE_SIZE 100
#define DIR_ENTRY_LENGTH 13
#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <string.h>
#include <cstdlib>
#include <malloc.h>

using namespace std;