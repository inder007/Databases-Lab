#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<int> v = {1, 6, 34,54,543,23,7,76, 723, 23, 25, 10, 19, 1283, 4,8,12, 5, 9, 13, 12};
    cout << 1 << endl;
    cout << 1 << endl;
    cout << 1 << endl;
    for (int i = 0; i < 100; i++) {
        cout << 2 << endl;
        cout << i << endl;

    }
    cout << 5 << endl;
    cout << -1 << endl;
}