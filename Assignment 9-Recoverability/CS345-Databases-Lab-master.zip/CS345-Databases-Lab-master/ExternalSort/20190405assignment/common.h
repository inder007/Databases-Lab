#define DISK_PAGE_SIZE 3
#define MEM_FRAME_SIZE 3
#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <climits>
#include <cassert>

using namespace std;